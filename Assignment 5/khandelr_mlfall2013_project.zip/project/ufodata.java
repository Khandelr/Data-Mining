package assignment5;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Arrays;

public class ufodata {
	int dayOfWeek[];
	String uLocation[];
	int uLocCounter[];
	public ufodata(){
		dayOfWeek=new int[7];
	}
	public void findWeek(ufo ufo){
		for(int i=0;i<ufo.reportedAt.length;i++){
			String s=ufo.reportedAt[i]+"";
			//System.out.println(i);
			int year = Integer.parseInt(s.substring(0, 4));
			int month = Integer.parseInt(s.substring(4, 6));
			int day = Integer.parseInt(s.substring(6, 8));


			// First convert to Date. This is one of the many ways.
			String dateString = String.format("%d-%d-%d", year, month, day);
			Date date=null;
			try {
				date = new SimpleDateFormat("yyyy-M-d").parse(dateString);
			} 
			catch (ParseException e) {
				// TODO Auto-generated catch block
				//System.out.println(i);
				e.printStackTrace();
			}

			// Then get the day of week from the Date based on specific locale.
			String weekDay = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date);

			//System.out.println(dayOfWeek);
			if(weekDay.equalsIgnoreCase("sunday")){
				dayOfWeek[0]++;
			}
			else if(weekDay.equalsIgnoreCase("monday")){
				dayOfWeek[1]++;
			}
			else if(weekDay.equalsIgnoreCase("tuesday")){
				dayOfWeek[2]++;
			}
			else if(weekDay.equalsIgnoreCase("wednesday")){
				dayOfWeek[3]++;
			}
			else if(weekDay.equalsIgnoreCase("thursday")){
				dayOfWeek[4]++;
			}
			else if(weekDay.equalsIgnoreCase("friday")){
				dayOfWeek[5]++;
			}
			else if(weekDay.equalsIgnoreCase("saturday")){
				dayOfWeek[6]++;
			}
		}
		//return -1;
		for(int i=0;i<7;i++){
			System.out.println(dayOfWeek[i]);
		}
		System.out.println();
	}
	public void uniqLocation(ufo u){
		String uniqueLocation[]=new String[u.location.length];
		int iCounter=0, jCounter=0;
		boolean flag=true;
		int kCounter=0, uRow=0;
		for(int iRow=0;iRow<u.location.length;iRow++){
			for(uRow=0;uniqueLocation[uRow]!=null;uRow++){
				if(u.location[iRow].equalsIgnoreCase(uniqueLocation[uRow])){
					flag=false;
					break;
				}
			}
			if(flag){
				uniqueLocation[kCounter++]=u.location[iRow];
			}
			flag=true;
		}
		
		uLocation=new String[kCounter];
		uLocCounter=new int[kCounter];
		int locC[]=new int[kCounter];
		for(iCounter=0;uniqueLocation[iCounter]!=null;iCounter++){
			uLocation[iCounter]=uniqueLocation[iCounter];
		}
		for(iCounter=0;iCounter<u.location.length;iCounter++){
			for(jCounter=0;jCounter<uLocation.length;jCounter++){
				if(u.location[iCounter].equalsIgnoreCase(uLocation[jCounter])){
					break;
				}
			}
			uLocCounter[jCounter]++;
		}
		locC=uLocCounter;
		Arrays.sort(locC);
		int counter=0;
		for(iCounter=locC.length-1;iCounter>=0;iCounter--){
			
			for(jCounter=0;jCounter<uLocCounter.length;jCounter++){
				if(locC[iCounter]==uLocCounter[jCounter]){
					//break;
					System.out.println(uLocation[jCounter]+" : "+uLocCounter[jCounter]);
					
				}
			}
			++counter;
			if(counter==10){
				break;
			}
		}
		System.out.println();
		
	}
	public void majority(ufo ufo){
		int maleCounter=0, womenCounter=0;
		
		for(int i=0;i<ufo.description.length;i++){
			if(ufo.description[i].contains("male")||ufo.description[i].contains("Male")||ufo.description[i].contains("Man")||ufo.description[i].contains("man")){
				maleCounter++;
			}
			else if(ufo.description[i].contains("boy")||ufo.description[i].contains("Boy")||ufo.description[i].contains("father")||ufo.description[i].contains("Father")){
				maleCounter++;
			}
			else if(ufo.description[i].contains("female")||ufo.description[i].contains("Female")||ufo.description[i].contains("woman")||ufo.description[i].contains("Woman")){
				womenCounter++;
			}
			else if(ufo.description[i].contains("girl")||ufo.description[i].contains("Girl")||ufo.description[i].contains("mother")||ufo.description[i].contains("Mother")){
				womenCounter++;
			}
		}
		System.out.println("male counter"+maleCounter);
		System.out.println("women counter"+womenCounter);
	}
	public void particularTime(ufo ufo){
		
		int monCounter[]=new int[12];
		for(int i=0;i<ufo.reportedAt.length;i++){
			String s=ufo.reportedAt[i]+"";
			//System.out.println(i);
			//int year = Integer.parseInt(s.substring(0, 4));
			int month = Integer.parseInt(s.substring(4, 6));
			//int day = Integer.parseInt(s.substring(6, 8));
			monCounter[month-1]++;
		}
		for(int i=0;i<monCounter.length;i++){
			System.out.println(monCounter[i]);
		}
	}
	/*public void uniqTime(ufo u){
		int uniqueTime[]=new int[u.reportedAt.length];
		int iCounter=0, jCounter=0;
		boolean flag=true;
		int kCounter=0, uRow=0;
		for(int iRow=0;iRow<u.reportedAt.length;iRow++){
			String s=u.reportedAt[iRow]+"";
			int year = Integer.parseInt(s.substring(0, 4));
			
			for(uRow=0;uniqueTime[uRow]!=0;uRow++){
				//System.out.println(i);
				
				if(u.reportedAt[iRow]==year){
					flag=false;
					break;
				}
			}
			if(flag){
				uniqueTime[kCounter++]=year;
			}
			flag=true;
		}
		
		int uTime[]=new int[kCounter];
		int uTimeCounter[]=new int[kCounter];
		for(iCounter=0;uTime[iCounter]!=0;iCounter++){
			uTime[iCounter]=uniqueTime[iCounter];
		}
		for(iCounter=0;iCounter<u.reportedAt.length;iCounter++){
			String s=u.reportedAt[iCounter]+"";
			int year = Integer.parseInt(s.substring(0, 4));
			
			for(jCounter=0;jCounter<uTime.length;jCounter++){
				if(uTime[jCounter]==year){
					break;
				}
			}
			uTimeCounter[jCounter]++;
		}
		for(int i=0;i<uTime.length;i++){
			System.out.println(uTime[i]+":"+uTimeCounter[i]);
		}
		System.out.println();
		
	}*/
	public static void main(String args[]){
		ufo u= new ufo();
		u.initializeData();
		ufodata ufoData=new ufodata();
		//ufoData.findWeek(u);
		ufoData.uniqLocation(u);
		//ufoData.majority(u);
		//ufoData.particularTime(u);
		//ufoData.uniqTime(u);
	}
}
