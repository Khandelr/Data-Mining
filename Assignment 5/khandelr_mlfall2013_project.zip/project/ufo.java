package assignment5;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ufo {
	long sightedAt[];
	long reportedAt[];
	String location[];
	String shape[];
	String duration[];
	String description[];
	public ufo(){
		String csvFile = "C:/Users/Ramakant Khandel/Desktop/Data Mining/UFO/chimps_16154-2010-10-20_14-33-35/ufo_awesome.json";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		int iColumn=0;
		int iRow=0,session=35,rCounter=0,dCounter=0;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				iRow++;
			}
			sightedAt=new long[iRow];
			reportedAt=new long[iRow];
			location= new String[iRow];
			shape=new String[iRow];
			duration= new String[iRow];
			description=new String[iRow];
			//System.out.println(iRow);
				
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	
	}
	public void initializeData(){
		String csvFile = "C:/Users/Ramakant Khandel/Desktop/Data Mining/UFO/chimps_16154-2010-10-20_14-33-35/ufo_awesome.json";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String[] data;
		String []content;
		int iCounter=0,jCounter=0,kCounter=0; 
		
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				//line=line.replaceAll("\"", "");
				line=line.replaceAll("[{}]", "");
				//line=line.replaceAll("}", "");
				data= line.split("\", \"");
				for(iCounter=0;iCounter<data.length;iCounter++){
					data[iCounter]=data[iCounter].replaceAll("\", \"","");
					content=data[iCounter].split("\": \"");
					/*for(jCounter=0;jCounter<content.length;jCounter++){
					/*if(content[0].equalsIgnoreCase("sighted_at")||content[0].equalsIgnoreCase("reportted_at")||
					content[0].equalsIgnoreCase("location")||content[0].equalsIgnoreCase("shape")||
					content[0].equalsIgnoreCase("duration")||content[0].equalsIgnoreCase("description"))*/
					/*System.out.println(content[jCounter].length()+"jCounter"+content[jCounter]);
					}*/
					if(content[0].replaceAll("\"", "").equalsIgnoreCase("sighted_at")){
						sightedAt[kCounter]=Long.parseLong(content[1].trim());
					}
					else if(content[0].replaceAll("\"", "").equalsIgnoreCase("reported_at")){
						reportedAt[kCounter]=Long.parseLong(content[1].trim());
					}
					else if(content[0].replaceAll("\"", "").equalsIgnoreCase("location")){
						location[kCounter]=content[1];
					}
					else if(content[0].replaceAll("\"", "").equalsIgnoreCase("shape")){
						if(content.length>1){
							shape[kCounter]=content[1];
						}
					}
					else if(content[0].replaceAll("\"", "").equalsIgnoreCase("duration")){
						if(content.length>1){
							duration[kCounter]=content[1];
						}
					}
					else if(content[0].replaceAll("\"", "").equalsIgnoreCase("description")){
						if(content.length>1){
							description[kCounter]=content[1];
						}
					}
				}
				kCounter++;
			//break;
			}
		System.out.println();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String args[]){
		ufo u= new ufo();
		u.initializeData();
	}
}
