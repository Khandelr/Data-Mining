package Assignment;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class crossValidation {
	static float ppvTotal[]=new float[10];
	static int ppvCounter=0;
	static float weightedPPV=0;
	static void kmeans_algorithm(int no_of_centroids, float data[][],int iLimit,int no_of_parameters, int range){
			
			float centroid[][]=new float[no_of_centroids][no_of_parameters];
			int jCounter=0,min_sub=0,kCounter=0,mCounter=0,lCounter=0,counter=0,value=0;
			float distance[]=new float[no_of_centroids];
			int count_data[][]=new int[no_of_centroids][2];
			float change_centroid[][]=new float[no_of_centroids][no_of_parameters+1];
			float min=0,truePositive=0,falsePositive=0,ppv_total;
			boolean condition=true;
			int incrCounter=0;
			List<Integer> slist = new ArrayList<Integer>();
			Random rand = new Random();
			int pRandom=0;
			
			for(jCounter=0;jCounter<iLimit;jCounter++){
				if(jCounter<((range-1)*(iLimit/10)) || jCounter>=(value=((range)*(iLimit/10))>650?iLimit:(range*(iLimit/10)))){
					slist.add(jCounter);
				}
			}
			
			for(jCounter=0;jCounter<no_of_centroids;jCounter++){
				pRandom=rand.nextInt(iLimit-(iLimit/10));
				pRandom=slist.get(pRandom);
				System.out.println("value p"+pRandom);
				for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
					centroid[(jCounter%(iLimit/10))][kCounter-1]=data[pRandom][kCounter];
				}
			}
			
			while(condition){
				incrCounter++;
				if(incrCounter==20){
					break;
				}
				
				for(jCounter=0;jCounter<iLimit;jCounter++){
					if(jCounter<((range-1)*(iLimit/10)) || jCounter>=(value=((range)*(iLimit/10))>650?iLimit:(range*(iLimit/10)))){
					min_sub=0;
					
						for(mCounter=0;mCounter<no_of_centroids;mCounter++){
							for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
								distance[mCounter]+=Math.pow((centroid[mCounter][kCounter-1]-data[jCounter][kCounter]),2);
							}
							distance[mCounter]=(float) Math.sqrt(distance[mCounter]);
						}
					
						min=distance[0];
					
						for(lCounter=0;lCounter<no_of_centroids;lCounter++){
							if(min>distance[lCounter]){
								min_sub=lCounter;
								distance[lCounter]=0;
							}
							else{
								distance[lCounter]=0;
							}
						}
					
						data[jCounter][11]=min_sub+1;
						for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
							change_centroid[min_sub][kCounter-1]+=data[jCounter][kCounter];
						}
						change_centroid[min_sub][kCounter-1]++;
					}
				}
				for(jCounter=0;jCounter<(no_of_centroids);jCounter++){
					for(kCounter=0;kCounter<no_of_parameters;kCounter++){
						change_centroid[jCounter][kCounter]=change_centroid[jCounter][kCounter]/change_centroid[jCounter][no_of_parameters];
					}
				}
				
				counter=0;
				
				for(jCounter=0;jCounter<(no_of_centroids);jCounter++){
					for(kCounter=0;kCounter<no_of_parameters;kCounter++){
						if(centroid[jCounter][kCounter]!=change_centroid[jCounter][kCounter]){
							break;
						}
					}
					if(kCounter>=no_of_parameters){
						counter++;
					}
					if(counter==no_of_centroids){
						condition=false;
					}
				}
					
				for(mCounter=0;mCounter<no_of_centroids;mCounter++){
					for(kCounter=0;kCounter<no_of_parameters;kCounter++){
						centroid[mCounter][kCounter]=change_centroid[mCounter][kCounter];
						change_centroid[mCounter][kCounter]=0;		
					}
					change_centroid[mCounter][kCounter]=0;		
				}
			}
			for(jCounter=((range-1)*(iLimit/10));jCounter<(value=((range)*(iLimit/10))>650?iLimit:(range*(iLimit/10)));jCounter++){
				min_sub=0;
				for(mCounter=0;mCounter<no_of_centroids;mCounter++){
					for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
						distance[mCounter]+=Math.pow((centroid[mCounter][kCounter-1]-data[jCounter][kCounter]),2);
					}
					distance[mCounter]=(float) Math.sqrt(distance[mCounter]);
				}
				min=distance[0];
				for(lCounter=0;lCounter<no_of_centroids;lCounter++){
					if(min>distance[lCounter]){
						min_sub=lCounter;
						distance[lCounter]=0;
					}
					else{
						distance[lCounter]=0;
					}
				}
				data[jCounter][11]=min_sub+1;
			}
			
			for(int nCounter=0;nCounter<no_of_centroids;nCounter++){
				for(mCounter=((range-1)*(iLimit/10));mCounter<(value=((range)*(iLimit/10))>650?iLimit:(range*(iLimit/10)));mCounter++){
					if(data[mCounter][11]==(nCounter+1) && data[mCounter][10]==2){
						count_data[nCounter][0]++;
					}
					else if(data[mCounter][11]==(nCounter+1) && data[mCounter][10]==4){
						count_data[nCounter][1]++;
					}
				}
			}
			for(int nCounter=0;nCounter<no_of_centroids;nCounter++){
				if(count_data[nCounter][0]>count_data[nCounter][1]){
					truePositive+=count_data[nCounter][0];
				}
				if(count_data[nCounter][0]<count_data[nCounter][1]){
					falsePositive+=count_data[nCounter][0];
				}
				if(count_data[nCounter][1]>count_data[nCounter][0]){
					truePositive+=count_data[nCounter][1];
				}
				if(count_data[nCounter][1]<count_data[nCounter][0]){
					falsePositive+=count_data[nCounter][1];
				}
			}
			
			System.out.println("true positive :"+truePositive);
			System.out.println("false positive :"+falsePositive);
			ppvTotal[ppvCounter]=truePositive/(truePositive+falsePositive);
			ppvCounter++;
			
							
	}
		
		public static void main(String args[]){
			try {
		        String inputLine;
		        float ppv_total=0;
		        int iCounter=0,j=0,kCounter=0;
		        float data[][]=new float[699][12];
		        URL url = new URL("http://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data");
		        BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
		        
		        while ((inputLine = in.readLine()) != null){
		          if(!inputLine.contains("?")){
		        		for (String retval: inputLine.split(",")){
		            		if(!retval.equalsIgnoreCase("?")){
		                		data[iCounter][kCounter]=Float.parseFloat(retval);
		                	}
		                	else{
		                		data[iCounter][kCounter]=-1;
		                	}
		            		kCounter++;
		        		}
		        		iCounter++;
		        		kCounter=0;
		        	}
		        }
		        for(int range=1;range<=10;range++){
		        	kmeans_algorithm(2,data,iCounter,9,range);
		        }
		        
		        in.close();
		        for(int jCounter=0;jCounter<ppvCounter;jCounter++){
					weightedPPV+=ppvTotal[jCounter];
				}
		        weightedPPV=weightedPPV/10;
			} 
			catch (Exception x) {
				x.printStackTrace();
			}
			try {
				
				PrintWriter writer=new PrintWriter(new FileWriter("C:\\Users\\Ramakant Khandel\\Desktop\\Submission\\khandelr_MLfall2013_Assignment3_Question2_Sub6.tex"));
				writer.println("\\documentclass{article}");
				writer.println("\\usepackage{amsfonts}"
					+ "\\topmargin 0pt"
					+ "\\advance \\topmargin by -\\headheight"
					+ "\\advance \\topmargin by -\\headsep"
					+ "\\textheight 8.9in"
					+ "\\oddsidemargin 0pt"
					+ "\\evensidemargin \\oddsidemargin"
					+ "\\marginparwidth 0.5in"
					+ "\\textwidth 6.5in");
				writer.println("\\title{ CSCI-B 565 DATA MINING\\\\");
				writer.println("Homework 1\\\\");
				writer.println("Morning class\\\\");
				writer.println("Computer Science Core \\\\ Fall 2013 \\\\ Indiana University}");
				writer.println("\\author{ Ramakant Khandel \\\\ khandelr@indiana.edu\\\\}");
				writer.println("\\date {October 11, 2013}");
				writer.println("\\begin{document}\\maketitle");
			
				writer.println("\\begin{center}");
				writer.println("All the work herein is solely mine\n\\\\");
			
				writer.println("\\begin{tabular}{c|c|c}");
				
				writer.println("Train & Test & PPV Result \\\\");
				writer.println("\\hline");
				
				writer.println("$C_{km=2}(D^*-{d_{1}^*})$ & $C_{km=2}(d_{1}^*)$ & "+ppvTotal[0]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{2}^*})$ & $C_{km=2}(d_{2}^*)$ & "+ppvTotal[1]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{3}^*})$ & $C_{km=2}(d_{3}^*)$ & "+ppvTotal[2]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{4}^*})$ & $C_{km=2}(d_{4}^*)$ & "+ppvTotal[3]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{5}^*})$ & $C_{km=2}(d_{5}^*)$ & "+ppvTotal[4]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{6}^*})$ & $C_{km=2}(d_{6}^*)$ & "+ppvTotal[5]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{7}^*})$ & $C_{km=2}(d_{7}^*)$ & "+ppvTotal[6]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{8}^*})$ & $C_{km=2}(d_{8}^*)$ & "+ppvTotal[7]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{9}^*})$ & $C_{km=2}(d_{9}^*)$ & "+ppvTotal[8]+"\\\\");
				writer.println("$C_{km=2}(D^*-{d_{10}^*})$ & $C_{km=2}(d_{10}^*)$ & "+ppvTotal[9]+"\\\\");
				
				writer.println("\\end{tabular}\\\\");
				writer.println("Weighted PPV="+weightedPPV+"\\\\");
				writer.println("\\end{center}");
			
				writer.println("\\end{document}");
			
				writer.close();
			}
			catch (Exception x) {
				System.out.println(x);
			}

		}
}


