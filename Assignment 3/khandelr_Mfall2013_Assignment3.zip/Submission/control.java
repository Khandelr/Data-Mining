

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class control {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String csvFileMain = "/N/u/khandelr/BigRed2/test/main.csv";
		String csvFileCandidate = "/N/u/khandelr/BigRed2/test/candidates.csv";
		
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		int incrCounter=0;
		int iCounter=0;
		int rowCounter=0;
		double value,attr6,attr5,attr4,min_distance;
	    int min_index=0,min_index_main=0,jCounter;
	    
		try {
	 
			br = new BufferedReader(new FileReader(csvFileMain));
			while ((line = br.readLine()) != null) {
				incrCounter++;
			}
			System.out.println("icounter main"+incrCounter);
			double dataMain[][]=new double[incrCounter-1][7];
			double dataControl[][]=new double[incrCounter-1][9];
			
			br = new BufferedReader(new FileReader(csvFileMain));
			while ((line = br.readLine()) != null) {
			        // use comma as separator
				String[] main = line.split(cvsSplitBy);
				for( jCounter=0;jCounter<main.length;jCounter++){
					//System.out.println("string "+main[j]);
					if(main[jCounter].matches(".*\\d.*")){
						 dataMain[rowCounter][jCounter]=Double.parseDouble(main[jCounter]);
						 //System.out.println(" data "+dataMain[rowCounter][j]);
					}
				}
				if(main[0].matches(".*\\d.*")){
					rowCounter++;
				}
			}
			incrCounter=0;
			
			rowCounter=0;
			br = new BufferedReader(new FileReader(csvFileCandidate));
			while ((line = br.readLine()) != null) {
				incrCounter++;
			}
			System.out.println("icounter candidate"+incrCounter);
			
			double dataCandidate[][]=new double[incrCounter-1][9];
			System.out.println("incrCounter "+incrCounter);
			br = new BufferedReader(new FileReader(csvFileCandidate));
			while ((line = br.readLine()) != null) {
			        // use comma as separator
				String[] candidate = line.split(cvsSplitBy);
				for( jCounter=0;jCounter<candidate.length;jCounter++){
					//System.out.println("string "+candidate[j]);
					if(candidate[jCounter].matches(".*\\d.*")){
						 dataCandidate[rowCounter][jCounter]=Double.parseDouble(candidate[jCounter]);
						// System.out.println(" data "+dataCandidate[rowCounter][j]);
					}
				}
				if(candidate[0].matches(".*\\d.*")){
					rowCounter++;
				}
				
			}
			
			for(iCounter=0;iCounter<dataMain.length;iCounter++){
		    	attr6=dataMain[iCounter][6]/0.2596;
			    attr5=dataMain[iCounter][5]/8.6;
			    attr4=dataMain[iCounter][4]/11.84;
			    min_distance=Math.sqrt(Math.pow(attr6,2)+Math.pow(attr5,2)+Math.pow(attr4,2));
	    		
		    	for(jCounter=0;jCounter<(dataCandidate.length);jCounter++){
		    		attr6=(dataMain[iCounter][6]-dataCandidate[jCounter][6])/0.2596;
		    		attr5=(dataMain[iCounter][5]-dataCandidate[jCounter][5])/8.6;
		    		attr4=((dataMain[iCounter][4]-dataMain[iCounter][5])-(dataCandidate[iCounter][4]-dataCandidate[iCounter][5]))/11.84;
		    		
		    		value=Math.sqrt(Math.pow(attr6,2)+Math.pow(attr5,2)+Math.pow(attr4,2));
		    		dataCandidate[jCounter][7]=value;
		    		if(min_distance>value){
		    			min_distance=value;
		    			min_index=jCounter;
		    			min_index_main=iCounter;
		    			}
		    		
		    	}
		    	System.out.println("min_index_main "+min_index_main);
	    		
		    	dataCandidate[min_index][8]=min_index_main+1;
		    	for(int kCounter=0;kCounter<9;kCounter++){
		    		dataControl[iCounter][kCounter]=dataCandidate[min_index][kCounter];
		    	} 	
		    }
		    System.out.println("for data control");
		    for(iCounter=0;iCounter<dataControl.length;iCounter++){
		    	for(jCounter=0;jCounter<dataControl[iCounter].length;jCounter++){
		    		System.out.print(dataControl[iCounter][jCounter]+"\t");
		    	}
		    	System.out.println();
		    }
		    FileWriter writer= new FileWriter("/N/u/khandelr/BigRed2/test/control.csv");
		    for(iCounter=0;iCounter<dataControl.length;iCounter++){
		    	for(jCounter=0;jCounter<dataControl[iCounter].length;jCounter++){
		    		writer.append(dataControl[iCounter][jCounter]+"");
		    		writer.append(',');
		    	}
		    	writer.append('\n');
		    }
		    writer.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}

