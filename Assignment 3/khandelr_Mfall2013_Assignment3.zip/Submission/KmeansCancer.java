package Assignment;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Random;

public class KmeansCancer {
	static float ppvTotal[]=new float[5];
	static int ppvCounter=0;
	static void kmeans_algorithm(int no_of_centroids, float data[][],int iLimit,int no_of_parameters){
		float centroid[][]=new float[no_of_centroids][no_of_parameters];
		int jCounter=0,min_sub=0,kCounter=0,mCounter=0,lCounter=0,counter=0;
		float distance[]=new float[no_of_centroids];
		int count_data[][]=new int[no_of_centroids][2];
		
		float truePositive=0,falsePositive=0;
		float change_centroid[][]=new float[no_of_centroids][no_of_parameters+1];
		float min=0;
		int incrCounter=0;
		boolean condition=true;
		Random rand = new Random();
		int pRandom=0;
		for(jCounter=0;jCounter<(no_of_centroids);jCounter++){
			pRandom=rand.nextInt(iLimit);
			for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
				centroid[jCounter][kCounter-1]=data[pRandom][kCounter];
			}
		}
		while(condition){
			
			incrCounter++;
			if(incrCounter==20){
				break;
			}
			
			for(jCounter=0;jCounter<iLimit;jCounter++){
				min_sub=0;
				for(mCounter=0;mCounter<no_of_centroids;mCounter++){
					for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
						distance[mCounter]+=Math.pow((centroid[mCounter][kCounter-1]-data[jCounter][kCounter]),2);
					}
					distance[mCounter]=(float) Math.sqrt(distance[mCounter]);
				}
				
				min=distance[0];
				for(lCounter=0;lCounter<no_of_centroids;lCounter++){
					if(min>distance[lCounter]){
						min_sub=lCounter;
						distance[lCounter]=0;
					}
					else{
						distance[lCounter]=0;
					}
				}
				data[jCounter][11]=min_sub+1;
				for(kCounter=1;kCounter<=no_of_parameters;kCounter++){
					change_centroid[min_sub][kCounter-1]+=data[jCounter][kCounter];
				}
				change_centroid[min_sub][kCounter-1]++;
			}
			for(jCounter=0;jCounter<(no_of_centroids);jCounter++){
				for(kCounter=0;kCounter<no_of_parameters;kCounter++){
					change_centroid[jCounter][kCounter]=change_centroid[jCounter][kCounter]/change_centroid[jCounter][no_of_parameters];
				}
			}
			counter=0;
			for(jCounter=0;jCounter<no_of_centroids;jCounter++){
				for(kCounter=0;kCounter<no_of_parameters;kCounter++){
					if(centroid[jCounter][kCounter]!=change_centroid[jCounter][kCounter]){
						break;
					}
				}
				if(kCounter>=no_of_parameters){
					counter++;
				}
				if(counter==no_of_centroids){
					condition=false;
				}
			}
			for(mCounter=0;mCounter<no_of_centroids;mCounter++){
				for(kCounter=0;kCounter<no_of_parameters;kCounter++){
					centroid[mCounter][kCounter]=change_centroid[mCounter][kCounter];
					change_centroid[mCounter][kCounter]=0;		
				}
				change_centroid[mCounter][kCounter]=0;		
			}
			
		}
		
		for(int nCounter=0;nCounter<no_of_centroids;nCounter++){
			for(mCounter=0;mCounter<iLimit;mCounter++){
				if(data[mCounter][11]==(nCounter+1) && data[mCounter][10]==2){
					count_data[nCounter][0]++;
				}
				else if(data[mCounter][11]==(nCounter+1) && data[mCounter][10]==4){
					count_data[nCounter][1]++;
				}
		    }
	    }
		/*for(int nCounter=0;nCounter<no_of_centroids;nCounter++){
			for(int gCounter=0;gCounter<2;gCounter++){
				System.out.println("data count"+count_data[nCounter][gCounter]);
			}
		}*/
		for(int nCounter=0;nCounter<no_of_centroids;nCounter++){
			if(count_data[nCounter][0]>count_data[nCounter][1]){
				truePositive+=count_data[nCounter][0];
				
			}
			if(count_data[nCounter][0]<count_data[nCounter][1]){
				falsePositive+=count_data[nCounter][0];
				
			}
			if(count_data[nCounter][1]>count_data[nCounter][0]){
				truePositive+=count_data[nCounter][1];
			}
			if(count_data[nCounter][1]<count_data[nCounter][0]){
				falsePositive+=count_data[nCounter][1];
			}
			
		}
		System.out.println("true positive :"+truePositive);
		System.out.println("false positive :"+falsePositive);
		ppvTotal[ppvCounter]=truePositive/(truePositive+falsePositive);
		ppvCounter++;
}
	
	public static void main(String args[]){
		try {
	        String inputLine;
	        
	        int iCounter=0,j=0,kCounter=0;
	        float data[][]=new float[699][12];
	        URL url = new URL("http://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data");
	        BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
	        while ((inputLine = in.readLine()) != null){
	            //System.out.println(inputLine);
	        	if(!inputLine.contains("?")){
	        		for (String retval: inputLine.split(",")){
	            		if(!retval.equalsIgnoreCase("?")){
	                		data[iCounter][kCounter]=Float.parseFloat(retval);
	                	}
	                	else{
	                		data[iCounter][kCounter]=-1;
	                	}
	            		kCounter++;
	        		}
	        		iCounter++;
	        		kCounter=0;
	        	}
	        }
	        kmeans_algorithm(2,data,iCounter,9);
	        kmeans_algorithm(2,data,iCounter,7);
	        kmeans_algorithm(2,data,iCounter,5);
	        kmeans_algorithm(2,data,iCounter,3);
	        kmeans_algorithm(2,data,iCounter,2);
	        
	        /*for(j=0;j<i;j++){
	        	for(k=0;k<12;k++){
	        		System.out.print(data[j][k]+"\t");
	        	}
	        	System.out.println();
	        }
	        
	        System.out.println("i "+i);
	        */
	        in.close();
	        } 
			catch (Exception x) {
				//System.out.println(x);
				x.printStackTrace();
			}
			try {
				
				PrintWriter writer=new PrintWriter(new FileWriter("C:\\Users\\Ramakant Khandel\\Desktop\\Submission\\khandelr_MLfall2013_Assignment3_Question2_Sub5.tex"));
				writer.println("\\documentclass{article}");
				writer.println("\\usepackage{amsfonts}"
					+ "\\topmargin 0pt"
					+ "\\advance \\topmargin by -\\headheight"
					+ "\\advance \\topmargin by -\\headsep"
					+ "\\textheight 8.9in"
					+ "\\oddsidemargin 0pt"
					+ "\\evensidemargin \\oddsidemargin"
					+ "\\marginparwidth 0.5in"
					+ "\\textwidth 6.5in");
				writer.println("\\title{ CSCI-B 565 DATA MINING\\\\");
				writer.println("Homework 1\\\\");
				writer.println("Morning class\\\\");
				writer.println("Computer Science Core \\\\ Fall 2013 \\\\ Indiana University}");
				writer.println("\\author{ Ramakant Khandel \\\\ khandelr@indiana.edu\\\\}");
				writer.println("\\date {October 11, 2013}");
				writer.println("\\begin{document}\\maketitle");
			
				writer.println("\\begin{center}");
				writer.println("All the work herein is solely mine\n\\\\");
			
				writer.println("\\begin{tabular}{c|c}");
				writer.println("C$_{km=2}(\\Delta^*)$ & PPV \\\\");
				writer.println("\\hline");
				writer.println("$A_{1},.....,A_{9}$ &  "+ppvTotal[0]+"\\\\");
				writer.println("$A_{1},.....,A_{7}$ &  "+ppvTotal[1]+"\\\\");
				writer.println("$A_{1},.....,A_{5}$ &  "+ppvTotal[2]+"\\\\");
				writer.println("$A_{1},.....,A_{3}$ &  "+ppvTotal[3]+"\\\\");
				writer.println("$A_{1},A_{2}$ &  "+ppvTotal[4]+"\\\\");
				
				
				/*for(int iCounter=0;iCounter<ppvCounter;iCounter++){
					writer.println(iCounter+" &"+ ppvTotal[iCounter]);
					writer.println("\\hline");
				}*/
			
				writer.println("\\end{tabular}");
			
				writer.println("\\end{center}");
			
				writer.println("\\end{document}");
			
				writer.close();
			}
			catch (Exception x) {
				System.out.println(x);
			}
	}
}