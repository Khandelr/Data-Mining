package assignment3;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;

public class missingTuples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float data[][]=new float[699][11];
        float dataM[][]= new float[16][11];
        
		try{
			String inputLine;
	        double mean=0;
	        int iCounter=0,jCounter=0,kCounter=0;
	        URL url = new URL("http://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data");
	        BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
	        while ((inputLine = in.readLine()) != null){
	            //System.out.println(inputLine);
	        	if(!inputLine.contains("?")){
	        		for (String retval: inputLine.split(",")){
	            		if(!retval.equalsIgnoreCase("?")){
	                		data[iCounter][kCounter]=Float.parseFloat(retval);
	                	}
	                	else{
	                		data[iCounter][kCounter]=-1;
	                	}
	            		kCounter++;
	        		}
	        		mean+=data[iCounter][6];
	        		iCounter++;
	        		kCounter=0;
	        	}
	        	else{
	        		for (String retval: inputLine.split(",")){
	            		if(!retval.equalsIgnoreCase("?")){
	                		dataM[jCounter][kCounter]=Float.parseFloat(retval);
	                	}
	                	else{
	                		dataM[jCounter][kCounter]=-1;
	                	}
	            		kCounter++;
	        		}
	        		jCounter++;
	        		kCounter=0;
	        	}
	        	
	        	}
	        System.out.println("mean "+mean);
	        for(int l=0;l<dataM.length;l++){
	        	dataM[l][6]=(float) (mean/(iCounter-1));
	        	for(int m=0;m<dataM[l].length;m++){
	        		System.out.print(dataM[l][m]+"\t");
	        	}
	        	System.out.println();
	        }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		try {
			
			PrintWriter writer=new PrintWriter(new FileWriter("C:\\Users\\Ramakant Khandel\\Desktop\\Submission\\khandelr_MLfall2013_Assignment3_Question2_Sub3.tex"));
			writer.println("\\documentclass{article}");
			writer.println("\\usepackage{amsfonts}"
				+ "\\topmargin 0pt"
				+ "\\advance \\topmargin by -\\headheight"
				+ "\\advance \\topmargin by -\\headsep"
				+ "\\textheight 8.9in"
				+ "\\oddsidemargin 0pt"
				+ "\\evensidemargin \\oddsidemargin"
				+ "\\marginparwidth 0.5in"
				+ "\\textwidth 6.5in");
			writer.println("\\title{ CSCI-B 565 DATA MINING\\\\");
			writer.println("Homework 1\\\\");
			writer.println("Morning class\\\\");
			writer.println("Computer Science Core \\\\ Fall 2013 \\\\ Indiana University}");
			writer.println("\\author{ Ramakant Khandel \\\\ khandelr@indiana.edu\\\\}");
			writer.println("\\date {October 11, 2013}");
			writer.println("\\begin{document}\\maketitle");
		
			writer.println("\\begin{center}");
			writer.println("All the work herein is solely mine\n\\\\");
			writer.println("\\begin{tabular}{c|c|c}");
			for(int l=0;l<dataM.length;l++){
	        		writer.print(dataM[l][0]+" &?& "+dataM[l][6]);
	        	writer.println("\\\\");
			}
			writer.println("\\end{tabular}");
			
			writer.println("\\end{center}");
		
			writer.println("\\end{document}");
		
			writer.close();
		}
		catch (Exception x) {
			System.out.println(x);
		}
	}

}
