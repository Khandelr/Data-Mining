
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;


public class KmeansAlgorithm {
	

	
		
		static void kmeans_algorithm(double centroid[][], int no_of_centroids, double data[][],int i,int no_of_parameters){
			//float centroid[][]=new float[no_of_centroids][no_of_parameters];
			int j=0,min_sub=0,k=0,m=0,l=0,counter=0;
			float distance[]=new float[no_of_centroids];
			int count_data[][]=new int[no_of_centroids][2];
			float change_centroid[][]=new float[no_of_centroids][no_of_parameters+1];
			float min=0;
			int incrCounter=0;
			boolean condition=true;
			double value,attr6,attr5,attr4,min_distance=0;
		    int min_index=0,min_index_main=0;
		    //System.out.println("no of centroids :"+no_of_centroids);
		    //System.out.println("i :"+i);
		    //System.out.println("no of parameters :"+no_of_parameters);
		    /*for(j=0;j<centroid.length;j++){
		    	for(k=0;k<centroid[j].length;k++){
		    		System.out.print("centroid "+centroid[j][k]+"\t");
		    	}
		    	System.out.println();
		    }*/
			while(condition){
				//counter++;
				incrCounter++;
				System.out.println("incrcounter "+incrCounter);
				if(incrCounter==20){
					break;
				}
				for(j=0;j<i;j++){
					min_sub=0;
					attr6=data[j][6]/0.2596;
				    attr5=data[j][5]/8.6;
				    attr4=data[j][4]/11.84;
				    min_distance=Math.sqrt(Math.pow(attr6,2)+Math.pow(attr5,2)+Math.pow(attr4,2));
		    		
					for(m=0;m<no_of_centroids;m++){
						//System.out.println("centroid[m][5] "+m+":"+centroid[m][5]);
						//System.out.println("data[j][6] "+j+":"+data[j][6]);
						attr6=(centroid[m][5]-data[j][6])/0.2596;
						//System.out.println("attr 6 :"+attr6);
						//System.out.println();
						//	System.out.println("centroid[m][4] "+centroid[m][4]);
					//	System.out.println("data[j][5] "+data[j][5]);
			    		attr5=(centroid[m][4]-data[j][5])/8.6;
			    	//	System.out.println("attr 5 m:"+m+" :j :"+j+" :attr5:"+attr5);
			    	//	System.out.println("centroid[m][3] "+centroid[m][3]);
			    		//System.out.println("centroid[m][4] "+centroid[m][4]);
			    	//	System.out.println("data[j][4] "+data[j][4]);
			    	//	System.out.println("data[j][4] "+data[j][5]);
			    		attr4=((centroid[m][3]-centroid[m][4])-(data[j][4]-data[j][5]))/11.84;
			    	//	System.out.println("attr 4 m:"+m+" :j :"+j+"attr4 :"+attr4);
			    		value=Math.sqrt(Math.pow(attr6,2)+Math.pow(attr5,2)+Math.pow(attr4,2));
			    	//	System.out.println("value "+value);
			    		if(min_distance>value){
			    			min_distance=value;
			    			min_index=m;
			    			min_index_main=j;
			    		}
					}
					data[j][7]=(float) min_distance;
					data[j][8]=min_index+1;
					//System.out.println("1");
					for(k=1;k<=no_of_parameters;k++){
						change_centroid[min_index][k-1]+=data[j][k];
						//System.out.println("change centroid :"+change_centroid[min_index][k-1]);
					}
					//System.out.println("k"+k);
					change_centroid[min_index][k-1]++;
				}
				for(j=0;j<(no_of_centroids);j++){
					for(k=0;k<no_of_parameters;k++){
						if(change_centroid[j][no_of_parameters]>0){
							change_centroid[j][k]=change_centroid[j][k]/change_centroid[j][no_of_parameters];
						}
					}
				}
				/*for(j=0;j<(no_of_centroids);j++){
					for(k=0;k<no_of_parameters;k++){
						System.out.println("current centroid "+centroid[j][k]);
						System.out.println("change centroid "+change_centroid[j][k]);
					}
				}*/
				counter=0;
				for(j=0;j<(no_of_centroids);j++){
					for(k=0;k<no_of_parameters;k++){
						if(centroid[j][k]!=change_centroid[j][k]){
							break;
						}
					}
					if(k>=no_of_parameters){
						counter++;
					}
					if(counter==no_of_centroids){
						condition=false;
						
						System.out.println("condition "+condition);
					}
				}
				for(m=0;m<no_of_centroids;m++){
					for(k=0;k<no_of_parameters;k++){
						centroid[m][k]=change_centroid[m][k];
						change_centroid[m][k]=0;		
					}
					change_centroid[m][k]=0;		
				}
				
			}
			
					
		}
		
		public static void main(String args[]){
			
		 		try {
					int j,k;
				    int rowCountera=0,rowCounterb=0,rowCounterc=0;
				    String csvFileMain = "/N/u/khandelr/BigRed2/main.csv";
					String csvFileCandidate = "/N/u/khandelr/BigRed2/candidates.csv";
					
					BufferedReader br = null;
					String line = "";
					String cvsSplitBy = ",";
					
					br = new BufferedReader(new FileReader(csvFileMain));
					while ((line = br.readLine()) != null) {
						String[] main = line.split(cvsSplitBy);
						if(main[1].matches(".*\\d.*") && main[1].equalsIgnoreCase("0")){
							rowCountera++;
						}
						if(main[1].matches(".*\\d.*") && main[1].equalsIgnoreCase("1")){
							rowCounterb++;
						}	
						if(main[1].matches(".*\\d.*") && main[1].equalsIgnoreCase("2")){
							rowCounterc++;
						}
							//iCounter++;
					}
						//System.out.println("icounter main"+iCounter);
					double dataMaina[][]=new double[rowCountera][6];
					double dataMainb[][]=new double[rowCounterb][6];
					double dataMainc[][]=new double[rowCounterc][6];
					rowCountera=0;
					rowCounterb=0;
					rowCounterc=0;
						
					br = new BufferedReader(new FileReader(csvFileMain));
					while ((line = br.readLine()) != null) {
						        // use comma as separator
						String[] main = line.split(cvsSplitBy);
						for( j=1;j<main.length;j++){
								//System.out.println("string "+main[j]);
							if(main[j].matches(".*\\d.*") && main[1].equalsIgnoreCase("0")){
								dataMaina[rowCountera][j-1]=Double.parseDouble(main[j]);
									 //System.out.println(" data "+dataMain[rowCounter][j]);
									if(j==main.length-1){
										 rowCountera++;
									}
							}
							if(main[j].matches(".*\\d.*") && main[1].equalsIgnoreCase("1")){
								dataMainb[rowCounterb][j-1]=Double.parseDouble(main[j]);
									 //System.out.println(" data "+dataMain[rowCounter][j]);
								if(j==main.length-1){
									rowCounterb++;
								}
							}
							if(main[j].matches(".*\\d.*") && main[1].equalsIgnoreCase("2")){
								dataMainc[rowCounterc][j-1]=Double.parseDouble(main[j]);
									 //System.out.println(" data "+dataMain[rowCounter][j]);
								if(j==main.length-1){
									rowCounterc++;
								}
							}
						}
							/*if(main[0].matches(".*\\d.*")){
								rowCounter++;
							}*/
							/*i++;
							if(i==3){
								break;
							}*/
						}
						rowCountera=0;
						rowCounterb=0;
						rowCounterc=0;
						br = new BufferedReader(new FileReader(csvFileCandidate));
						while ((line = br.readLine()) != null) {
							String[] candidate = line.split(cvsSplitBy);
							if(candidate[1].matches(".*\\d.*") && candidate[1].equalsIgnoreCase("0")){
								rowCountera++;
							}
							if(candidate[1].matches(".*\\d.*") && candidate[1].equalsIgnoreCase("1")){
								rowCounterb++;
							}	
							if(candidate[1].matches(".*\\d.*") && candidate[1].equalsIgnoreCase("2")){
								rowCounterc++;
							}
							//iCounter++;
						}
						//System.out.println("icounter main"+iCounter);
						double dataCandidatea[][]=new double[rowCountera][9];
						double dataCandidateb[][]=new double[rowCounterb][9];
						double dataCandidatec[][]=new double[rowCounterc][9];
						rowCountera=0;
						rowCounterb=0;
						rowCounterc=0;
						
						br = new BufferedReader(new FileReader(csvFileCandidate));
						while ((line = br.readLine()) != null) {
						        // use comma as separator
							String[] candidate = line.split(cvsSplitBy);
							for( j=0;j<candidate.length;j++){
								//System.out.println("string "+main[j]);
								if(candidate[j].matches(".*\\d.*") && candidate[1].equalsIgnoreCase("0")){
									 dataCandidatea[rowCountera][j]=Double.parseDouble(candidate[j]);
									 //System.out.println(" data "+dataMain[rowCounter][j]);
									 if(j==candidate.length-1){
										 rowCountera++;
									 }
								}
								if(candidate[j].matches(".*\\d.*") && candidate[1].equalsIgnoreCase("1")){
									 dataCandidateb[rowCounterb][j]=Double.parseDouble(candidate[j]);
									 //System.out.println(" data "+dataMain[rowCounter][j]);
									 if(j==candidate.length-1){
										 rowCounterb++;
									 }
								}
								if(candidate[j].matches(".*\\d.*") && candidate[1].equalsIgnoreCase("2")){
									 dataCandidatec[rowCounterc][j]=Double.parseDouble(candidate[j]);
									 //System.out.println(" data "+dataMain[rowCounter][j]);
									 if(j==candidate.length-1){
										 rowCounterc++;
									 }
								}
							}
							/*if(main[0].matches(".*\\d.*")){
								rowCounter++;
							}*/
							/*i++;
							if(i==3){
								break;
							}*/
						}
						/*System.out.println("for data main a");
						for(j=0;j<dataMaina.length;j++){
							for(k=0;k<dataMaina[j].length;k++){
								System.out.print(dataMaina[j][k]+"\t");
							}
							System.out.println();
						}
						System.out.println("the value for data main a"+j);*/
						/*System.out.println("for data main b");
						for(j=0;j<dataMainb.length;j++){
							for(k=0;k<dataMainb[j].length;k++){
								System.out.print(dataMainb[j][k]+"\t");
							}
							System.out.println();
						}*/
						/*System.out.println("for data main c");
						for(j=0;j<dataMainc.length;j++){
							for(k=0;k<dataMainc[j].length;k++){
								System.out.print(dataMainc[j][k]+"\t");
							}
							System.out.println();
						}*/
						/*System.out.println("for data candidate a");
						for(j=0;j<dataCandidatea.length;j++){
							for(k=0;k<dataCandidatea[j].length;k++){
								System.out.print(dataCandidatea[j][k]+"\t");
							}
							System.out.println();
						}
						System.out.println("the value for candidate a",j);*/ 
						/*System.out.println("for data candidate b");
						for(j=0;j<dataCandidateb.length;j++){
							for(k=0;k<dataCandidateb[j].length;k++){
								System.out.print(dataCandidateb[j][k]+"\t");
							}
							System.out.println();
						}
						System.out.println("the value for data candidate b"+j);*/
						/*System.out.println("for data candidate c");
						for(j=0;j<dataCandidatec.length;j++){
							for(k=0;k<dataCandidatec[j].length;k++){
								System.out.print(dataCandidatec[j][k]+"\t");
							}
							System.out.println();
						}
						System.out.println("the value for data candidate c"+j);*/
						//kmeans_algorithm(dataMainc, dataMainc.length, dataCandidatec, dataCandidatec.length,6);
						//kmeans_algorithm(dataMainb, dataMainb.length, dataCandidateb, dataCandidateb.length,6);
						kmeans_algorithm(dataMaina, dataMaina.length, dataCandidatea, dataCandidatea.length,6);
						
						
					/*	System.out.println("for data candidate c after function");
						for(j=0;j<dataCandidatec.length;j++){
							for(k=0;k<dataCandidatec[j].length;k++){
								System.out.print(dataCandidatec[j][k]+"\t");
							}
							System.out.println();
						}*/
					    FileWriter writer= new FileWriter("/N/u/khandelr/BigRed2/candidatea.csv");
					    for(int i=0;i<dataCandidatea.length;i++){
					    	for(j=0;j<dataCandidatea[i].length;j++){
					    		writer.append(dataCandidatea[i][j]+"");
					    		writer.append(',');
					    	}
					    	writer.append('\n');
					    }
					    writer.close();
					   /* FileWriter writer= new FileWriter("/N/u/khandelr/BigRed2/candidateb.csv");
					    for(int i=0;i<dataCandidateb.length;i++){
					    	for(j=0;j<dataCandidateb[i].length;j++){
					    		writer.append(dataCandidateb[i][j]+"");
					    		writer.append(',');
					    	}
					    	writer.append('\n');
					    }
					   writer.close();*/
					    /*FileWriter writer= new FileWriter("/N/u/khandelr/BigRed2/candidatec.csv");
					    for(int i=0;i<dataCandidatec.length;i++){
					    	for(j=0;j<dataCandidatec[i].length;j++){
					    		writer.append(dataCandidatec[i][j]+"");
					    		writer.append(',');
					    	}
					    	writer.append('\n');
					    }
					    writer.close();*/
					    /*writer= new FileWriter("/N/u/khandelr/BigRed2/maina.csv");
					    for(int i=0;i<dataMaina.length;i++){
					    	for(j=0;j<dataMaina[i].length;j++){
					    		writer.append(dataMaina[i][j]+"");
					    		writer.append(',');
					    	}
					    	writer.append('\n');
					    }
					    writer.close();
					    writer= new FileWriter("/N/u/khandelr/BigRed2/mainb.csv");
					    for(int i=0;i<dataMainb.length;i++){
					    	for(j=0;j<dataMainb[i].length;j++){
					    		writer.append(dataMainb[i][j]+"");
					    		writer.append(',');
					    	}
					    	writer.append('\n');
					    }
					    writer.close();
					    writer= new FileWriter("/N/u/khandelr/BigRed2/mainc.csv");
					    for(int i=0;i<dataMainc.length;i++){
					    	for(j=0;j<dataMainc[i].length;j++){
					    		writer.append(dataMainc[i][j]+"");
					    		writer.append(',');
					    	}
					    	writer.append('\n');
					    }
					    writer.close();*/
				}
			
		
		 		catch (Exception x) {
			        System.out.println(x);
			        x.printStackTrace();
			    }
	}

}

