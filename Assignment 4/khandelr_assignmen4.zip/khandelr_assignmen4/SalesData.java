	
	public class SalesData {
		String uProd[];
		String uId[];
		int pOk[];
		int pFraud[];
		int pInsp[];
		int iOk[];
		int iFraud[];
		int iInsp[];
		double centroidOne[];
		double centroidTwo[];
		
		public String[] getuProd() {
			return uProd;
		}
		public void setuProd(String[] uProd) {
			this.uProd = uProd;
		}
		public String[] getuId() {
			return uId;
		}
		public void setuId(String[] uId) {
			this.uId = uId;
		}
		public int[] getpOk() {
			return pOk;
		}
		public void setpOk(int[] pOk) {
			this.pOk = pOk;
		}
		public int[] getpFraud() {
			return pFraud;
		}
		public void setpFraud(int[] pFraud) {
			this.pFraud = pFraud;
		}
		public int[] getpInsp() {
			return pInsp;
		}
		public void setpInsp(int[] pInsp) {
			this.pInsp = pInsp;
		}
		public int[] getiOk() {
			return iOk;
		}
		public void setiOk(int[] iOk) {
			this.iOk = iOk;
		}
		public int[] getiFraud() {
			return iFraud;
		}
		public void setiFraud(int[] iFraud) {
			this.iFraud = iFraud;
		}
		public int[] getiInsp() {
			return iInsp;
		}
		public void setiInsp(int[] iInsp) {
			this.iInsp = iInsp;
		}
		public void initializeCentroid(Sales sales){
			for(int uRow=0;uRow<uProd.length;uRow++){
				for(int iRow=0; iRow<sales.insp.length; iRow++){
					if(uProd[uRow].equalsIgnoreCase(sales.prod[iRow]) && sales.insp[iRow].equalsIgnoreCase("ok") && centroidOne[uRow]==0 ){
						centroidOne[uRow]=sales.unitprice[iRow];
					}
					if(uProd[uRow].equalsIgnoreCase(sales.prod[iRow]) && sales.insp[iRow].equalsIgnoreCase("fraud") && centroidTwo[uRow]==0){
						centroidTwo[uRow]=sales.unitprice[iRow];
					}
					if(centroidOne[uRow]>0 && centroidTwo[uRow]>0){
						break;
					}
				}
			}
		}
		public SalesData(Sales sales){
			String uniqueprod[]=new String[sales.prod.length];
			int iCounter=0, jCounter=0;
			boolean flag=true;
			int kCounter=0, uRow=0;
			for(int iRow=0;iRow<sales.prod.length;iRow++){
				for(uRow=0;uniqueprod[uRow]!=null;uRow++){
					if(sales.prod[iRow].equalsIgnoreCase(uniqueprod[uRow])){
						flag=false;
						break;
					}
				}
				if(flag){
					uniqueprod[kCounter++]=sales.prod[iRow];
				}
				flag=true;
			}
			
			uProd = new String[kCounter];
			pOk = new int[kCounter];
			pFraud = new int[kCounter];
			pInsp = new int[kCounter];
			centroidOne=new double[kCounter];
			centroidTwo=new double[kCounter];
			
			for(iCounter=0;uniqueprod[iCounter]!=null;iCounter++){
					uProd[iCounter]=uniqueprod[iCounter];
			}
			
			for(iCounter=0;iCounter<sales.insp.length;iCounter++){
				for(jCounter=0;jCounter<uProd.length;jCounter++){
					if(sales.prod[iCounter].equalsIgnoreCase(uProd[jCounter])){
						break;
					}
				}
				if(sales.insp[iCounter].equalsIgnoreCase("ok")){
					pOk[jCounter]++;
				}
				if(sales.insp[iCounter].equalsIgnoreCase("fraud")){
					pFraud[jCounter]++;
				}
				pInsp[jCounter]++;
			}
			System.out.println("iCounter "+iCounter);				
			flag=true;
			kCounter=0;
			String uniqueid[]=new String[sales.id.length];
			for(int iRow=0;iRow<sales.id.length;iRow++){
				for(uRow=0;uniqueid[uRow]!=null;uRow++){
					if(sales.id[iRow].equalsIgnoreCase(uniqueid[uRow])){
						flag=false;
						break;
					}
				}
				if(flag){
					//flag=false;
					uniqueid[kCounter++]=sales.id[iRow];
				}
				flag=true;
			}
			uId = new String[kCounter];
			iOk = new int[kCounter];
			iFraud = new int[kCounter];
			iInsp = new int[kCounter];
			
			for(iCounter=0;uniqueid[iCounter]!=null;iCounter++){
				uId[iCounter]=uniqueid[iCounter];
			}
			for(iCounter=0;iCounter<sales.insp.length;iCounter++){
				for(jCounter=0;jCounter<uId.length;jCounter++){
					if(sales.id[iCounter].equalsIgnoreCase(uId[jCounter])){
						break;
					}
				}
				if(sales.insp[iCounter].equalsIgnoreCase("ok")){
					iOk[jCounter]++;
				}
				if(sales.insp[iCounter].equalsIgnoreCase("fraud")){
					iFraud[jCounter]++;
				}
				iInsp[jCounter]++;
			}
			
		}
		public static void main(String args[]){
			Sales sales = new Sales(); 
			SalesData salesdata= new SalesData(sales);
	

int k=0;
		System.out.println(salesdata.uProd.length);
			for(int i=0;i<salesdata.uProd.length;i++){
				if(salesdata.pOk[i]==0 && salesdata.pFraud[i]==0){
					//System.out.print(salesdata.uProd[i]+"\t");
					k++;			
					//System.out.print(salesdata.pOk[i]+"\t");
					//System.out.println(salesdata.pFraud[i]);
				}
			}
			System.out.println(k);
		}
	}

