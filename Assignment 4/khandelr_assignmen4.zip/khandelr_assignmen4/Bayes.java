
import java.io.PrintWriter;
import java.util.Random;

public class Bayes {
	double okmean;
	double okvariance;
	double okDeviation;
	double fraudmean;
	double fraudvariance;
	double fraudDeviation;
	double okNo;
	double fraudNo;
	void calculatemean(Sales sales){
		int okCounter=0, fraudCounter=0;
		int iRow=0;
		for(iRow=0;iRow<sales.unitprice.length;iRow++){
			if(sales.insp[iRow].equalsIgnoreCase("ok")){
				okCounter++;
				okmean+=sales.unitprice[iRow];
			}
			if(sales.insp[iRow].equalsIgnoreCase("fraud")){
				fraudCounter++;
				fraudmean+=sales.unitprice[iRow];
			}
		}
		okmean=okmean/okCounter;
		fraudmean=fraudmean/fraudCounter;
	}
	void calculateDeviation(Sales sales){
		calculatemean(sales);
		int iRow=0;
		int okCounter=0, fraudCounter=0;
		for(iRow=0;iRow<sales.unitprice.length;iRow++){
			if(sales.insp[iRow].equalsIgnoreCase("ok")){
				okvariance+=Math.pow((sales.unitprice[iRow]-okmean),2);
				okCounter++;
			}
			if(sales.insp[iRow].equalsIgnoreCase("fraud")){
				fraudvariance+=Math.pow((sales.unitprice[iRow]-fraudmean),2);
				fraudCounter++;
			}	
		}
		okvariance=okvariance/okCounter;
		fraudvariance=fraudvariance/fraudCounter;
		okDeviation=Math.pow(okvariance, 0.5);
		fraudDeviation=Math.pow(fraudvariance, 0.5);
		okNo=okCounter;
		fraudNo=fraudCounter;
		
	}
	public void calculateBayes(Sales sales, SalesData salesData){
		double forOk=0;
		double forFraud=0;
		int uRow=0;
		Random ran = new Random();
		for(int iRow=0;iRow<sales.insp.length;iRow++){
			if(sales.insp[iRow].equalsIgnoreCase("unkn")){
				for(uRow=0;uRow<salesData.uProd.length;uRow++){
					if(sales.prod[iRow].equalsIgnoreCase(salesData.uProd[uRow])){
						break;
					}
				}
				forOk=okNo/(okNo+fraudNo);
				forFraud=fraudNo/(okNo+fraudNo);
				if(salesData.iOk[uRow]>0 && salesData.iFraud[uRow]>0){
					forOk=forOk*(salesData.iOk[uRow]/okNo);
					forFraud=forFraud*(salesData.iFraud[uRow]/fraudNo);
				}
				else{
					int temp=ran.nextInt(salesData.iInsp[uRow]);
					if(temp==0){
						temp=1;
					}
					float mOk=(float)temp/salesData.iInsp[uRow];
					float mFraud=(float)(salesData.iInsp[uRow]-temp)/salesData.iInsp[uRow];
					forOk=forOk*mOk;
					forFraud=forFraud*mFraud;
				}
				if(salesData.pOk[uRow]>0 && salesData.pFraud[uRow]>0){
					forOk=forOk*(salesData.pOk[uRow]/okNo);
					forFraud=forFraud*(salesData.pFraud[uRow]/fraudNo);
				}
				else{
					int temp=ran.nextInt(salesData.pInsp[uRow]);
					if(temp==0){
						temp=1;
					}
					float mOk=(float)temp/salesData.pInsp[uRow];
					float mFraud=(float)(salesData.pInsp[uRow]-temp)/salesData.pInsp[uRow];
					forOk=forOk*mOk;
					forFraud=forFraud*mFraud;
				}
				double a=Math.pow(2*3.14141*okvariance, 0.5);
				double b=Math.pow(sales.unitprice[iRow]-okmean,2);
				double c=-b/(2*okvariance);
				a=a*Math.pow(2.71828,c);
				forOk=forOk*a;
				a=Math.pow(2*3.14141*fraudvariance, 0.5);
				b=Math.pow(sales.unitprice[iRow]-fraudmean,2);
				c=-b/(2*fraudvariance);
				a=a*Math.pow(2.71828,c);
				forFraud=forFraud*a;
				if(forOk>forFraud){
					sales.insp[iRow]="ok";
				}
				else if(forOk<forFraud){
					sales.insp[iRow]="fraud";
				}
			}
		}
		
	}
	void writeToFile(Sales sales){
		try{
			PrintWriter writer = new PrintWriter("/N/u/khandelr/BigRed2/assignment4/Bayes.csv", "UTF-8");
			//writer.println("The first line");
			//writer.println("The second line");
			for(int iRow=0;iRow<sales.insp.length;iRow++){
				writer.print(sales.id[iRow]+",");
				writer.print(sales.prod[iRow]+",");
				writer.print(sales.quant[iRow]+",");
				writer.print(sales.val[iRow]+",");
				writer.print(sales.unitprice[iRow]+",");
				writer.print(sales.insp[iRow]+"\n");
				
				//writer.print(sales.cluster[iRow]+"\n");
				
			}
			writer.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void main(String args[]){
		//int data[]={600,470,170430,300};
		Sales sales=new Sales();
		SalesData salesData= new SalesData(sales);
		Bayes bayes=new Bayes();
		
		bayes.calculateDeviation(sales);
		//SalesData salesdata= new SalesData(sales);
		bayes.calculateBayes(sales, salesData);
		bayes.writeToFile(sales);
		/*System.out.println("bayes okmean "+bayes.okmean);
		System.out.println("bayes fraud mean "+bayes.fraudmean);
		System.out.println("bayes okvarince "+bayes.okvariance);
		System.out.println("bayes fraud variance "+bayes.fraudvariance);*/
		
		
	}
	
}

