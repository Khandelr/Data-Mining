
import java.io.BufferedReader;
import java.io.FileReader;

public class Sales {
	String id[];
	String prod[];
	double quant[];
	double val[];
	String insp[];
	double unitprice[];
	String cluster[];
	public double[] getUnitprice() {
		return unitprice;
	}
	public String[] getCluster() {
		return cluster;
	}
	public void setCluster(String[] cluster) {
		this.cluster = cluster;
	}
	public void setUnitprice(double[] unitprice) {
		this.unitprice = unitprice;
	}
	public Sales(){
		String csvFile ="/N/u/khandelr/BigRed2/assignment4/Sales.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		int iRow=0;
		try {
			 
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				String[] data = line.split(cvsSplitBy);
				if(!data[3].equalsIgnoreCase("na")&& !data[4].equalsIgnoreCase("na")){
					iRow++;
				}
			}
			id=new String[iRow];
			prod=new String[iRow];
			quant= new double[iRow];
			val=new double[iRow];
			insp=new String[iRow];
			unitprice=new double[iRow];
			cluster=new String[iRow];
			iRow=0;
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				String[] data = line.split(cvsSplitBy);
				/*for(int j=0;j<data.length;j++){
					System.out.print(data[j]);
				}*/
				System.out.println();
				if(!data[3].equalsIgnoreCase("na")&&!data[4].equalsIgnoreCase("na")){
					id[iRow]=data[1];
					//System.out.println(id[iRow]);
					prod[iRow]=data[2];
					 //System.out.println(prod[iRow]);
					quant[iRow]=Double.parseDouble(data[3]);
					 //System.out.println(quant[iRow]);
					val[iRow]=Double.parseDouble(data[4]);
					 //System.out.println(val[iRow]);
					insp[iRow]=data[5];
					 //System.out.println("insp "+insp[iRow]);
					unitprice[iRow]=val[iRow]/quant[iRow];
					iRow++;
					//System.out.println(insp[iRow]);
					//if(iRow==3){
					//	break;		
					//}
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public String[] getId() {
		return id;
	}
	public void setId(String[] id) {
		this.id = id;
	}
	public String[] getProd() {
		return prod;
	}
	public void setProd(String[] prod) {
		this.prod = prod;
	}
	public double[] getQuant() {
		return quant;
	}
	public void setQuant(double[] quant) {
		this.quant = quant;
	}
	public double[] getVal() {
		return val;
	}
	public void setVal(double[] val) {
		this.val = val;
	}
	public String[] getInsp() {
		return insp;
	}
	public void setInsp(String[] insp) {
		this.insp = insp;
	}
	public static void main(String  args[]){
		Sales sales= new Sales();
	
	}
}

