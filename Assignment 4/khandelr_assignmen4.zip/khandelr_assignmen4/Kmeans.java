
import java.io.PrintWriter;

public class Kmeans {
	String clusterOne[];
	String clusterTwo[];
	public Kmeans(SalesData salesData){
		clusterOne=new String[salesData.uProd.length];
		clusterTwo=new String[salesData.uProd.length];
	}
	public String[] getClusterOne() {
		return clusterOne;
	}
	public void setClusterOne(String[] clusterOne) {
		this.clusterOne = clusterOne;
	}
	public String[] getClusterTwo() {
		return clusterTwo;
	}
	public void setClusterTwo(String[] clusterTwo) {
		this.clusterTwo = clusterTwo;
	}
	
	
	void checkCluster(Sales sales, SalesData salesData){
		int iRow=0, uRow=0;
		int oneOk[]=new int[salesData.uProd.length];
		int oneFraud[]=new int[salesData.uProd.length];
		int twoOk[]=new int[salesData.uProd.length];
		int twoFraud[]=new int[salesData.uProd.length];
		for(iRow=0;iRow<sales.insp.length;iRow++){
			
			if(sales.cluster[iRow]!=null){
				for(uRow=0;uRow<salesData.uProd.length;uRow++){
					if(sales.prod[iRow].equalsIgnoreCase(salesData.uProd[uRow])){
						break;
					}
				}
				if(sales.cluster[iRow].equalsIgnoreCase("cluster1") && sales.insp[iRow].equalsIgnoreCase("ok")){
					oneOk[uRow]++;
				}
				else if(sales.cluster[iRow].equalsIgnoreCase("cluster1") && sales.insp[iRow].equalsIgnoreCase("fraud")){
					oneFraud[uRow]++;
				}
				else if(sales.cluster[iRow].equalsIgnoreCase("cluster2") && sales.insp[iRow].equalsIgnoreCase("ok")){
					twoOk[uRow]++;
				}
				else if(sales.cluster[iRow].equalsIgnoreCase("cluster2") && sales.insp[iRow].equalsIgnoreCase("fraud")){
					twoFraud[uRow]++;
				}
			}
		}
		for(uRow=0;uRow<salesData.uProd.length;uRow++){
			if(oneOk[uRow]>oneFraud[uRow]){
				clusterOne[uRow]="ok";		
			}
			if(oneFraud[uRow]>oneOk[uRow]){
				clusterOne[uRow]="fraud";		
			}
			if(twoOk[uRow]>twoFraud[uRow]){
				clusterTwo[uRow]="ok";		
			}
			if(twoOk[uRow]<twoFraud[uRow]){
				clusterTwo[uRow]="fraud";		
			}
		}
	}
	void calculateCentroid(double valueOne[],double valueTwo[], int counterOne[], int counterTwo[]){
		for(int jCounter=0;jCounter<valueOne.length;jCounter++){
			if(counterOne[jCounter]>0){
				valueOne[jCounter]=valueOne[jCounter]/counterOne[jCounter];
			}
			if(counterTwo[jCounter]>0){
				valueTwo[jCounter]=valueTwo[jCounter]/counterTwo[jCounter];
			}
			valueOne[jCounter]=Math.floor(valueOne[jCounter]*10000)/10000;
			valueTwo[jCounter]=Math.floor(valueTwo[jCounter]*10000)/10000;
			counterOne[jCounter]=0;
			counterTwo[jCounter]=0;
			
		}
	}
	void calculateFlag(double valueOne[],double valueTwo[], SalesData salesData, boolean flag[]){
		for(int jCounter=0;jCounter<valueOne.length;jCounter++){
			
			if(valueOne[jCounter]==salesData.centroidOne[jCounter] && valueTwo[jCounter]==salesData.centroidTwo[jCounter] ){
				//System.out.println(loopCounter);
				flag[jCounter]=true;
				//break;
			}
		}
	}
	
	void assignCentroid(double valueOne[], double valueTwo[], SalesData salesData){
		for(int jCounter=0;jCounter<salesData.uProd.length;jCounter++){
			salesData.centroidOne[jCounter]=valueOne[jCounter];
			salesData.centroidTwo[jCounter]=valueTwo[jCounter];
			valueOne[jCounter]=0;
			valueTwo[jCounter]=0;
		}
	}
	void unsupervisedLearning(Sales sales, SalesData salesData){
		//SalesData salesData=new SalesData(sales);
		salesData.initializeCentroid(sales);
		int iRow=0, uRow=0;
		double oVal=0, tVal=0;
		boolean flag[]=new boolean[salesData.uProd.length];
		int oneCounter=0, twoCounter=0, loopCounter=0;
		double valueOne[]=new double[salesData.uProd.length];
		double valueTwo[]=new double[salesData.uProd.length];
		int counterOne[]=new int[salesData.uProd.length];
		int counterTwo[]=new int[salesData.uProd.length];
		
		while(true){
			loopCounter++;
			//oneCounter=0;
			//twoCounter=0;
			for(iRow=0;iRow<sales.insp.length;iRow++){
				if(sales.insp[iRow].equalsIgnoreCase("ok")||sales.insp[iRow].equalsIgnoreCase("fraud")){
					for(uRow=0;uRow<salesData.uProd.length;uRow++){
						if(sales.prod[iRow].equalsIgnoreCase(salesData.uProd[uRow])){
							break;
						}
					}
					if(!flag[uRow]&&salesData.centroidOne[uRow]>0 && salesData.centroidTwo[uRow]>0){
						oVal=Math.abs(sales.unitprice[iRow]-salesData.centroidOne[uRow]);
						tVal=Math.abs(sales.unitprice[iRow]-salesData.centroidTwo[uRow]);
						if(oVal>tVal){
							valueTwo[uRow]+=tVal;
							counterTwo[uRow]++;
							sales.cluster[iRow]="cluster2";
						}
						if(oVal<tVal){
							valueOne[uRow]+=oVal;
							counterOne[uRow]++;
							sales.cluster[iRow]="cluster1";
						}
					}
				}	
			}
			calculateCentroid(valueOne, valueTwo, counterOne, counterTwo);
			//counterOne=oneCounter;
			//counterTwo=twoCounter;
			calculateFlag(valueOne, valueTwo, salesData, flag);
			int jCounter=0;
			for(jCounter=0;jCounter<flag.length;jCounter++){
				if(!flag[jCounter]){
					break;
				}
				
			}
			if(jCounter==flag.length||loopCounter==2){
				break;
			}
			assignCentroid(valueOne, valueTwo, salesData);
		}
		checkCluster(sales, salesData);
	}
	void predictCluster(Sales sales, SalesData salesData){
		double oVal, tVal;
		int uRow=0;
		for(int iRow=0;iRow<sales.insp.length;iRow++){
			if(sales.insp[iRow].equalsIgnoreCase("unkn")){
				for(uRow=0;uRow<salesData.uProd.length;uRow++){
					if(sales.prod[iRow].equalsIgnoreCase(salesData.uProd[uRow])){
						break;
					}
				}
				oVal=Math.abs(sales.unitprice[iRow]-salesData.centroidOne[uRow]);
				tVal=Math.abs(sales.unitprice[iRow]-salesData.centroidTwo[uRow]);
				if(oVal>tVal){
					sales.insp[iRow]=clusterTwo[uRow];
					sales.cluster[iRow]="cluster2";
				}
				if(oVal<tVal){
					sales.insp[iRow]=clusterOne[uRow];
					sales.cluster[iRow]="cluster1";
				}
			}
		}
		
	}
	void writeToFile(Sales sales){
		try{
			PrintWriter writer = new PrintWriter("/N/u/khandelr/BigRed2/assignment4/Kmeans.csv", "UTF-8");
			//writer.println("The first line");
			//writer.println("The second line");
			for(int iRow=0;iRow<sales.insp.length;iRow++){
				writer.print(sales.id[iRow]+",");
				writer.print(sales.prod[iRow]+",");
				writer.print(sales.quant[iRow]+",");
				writer.print(sales.val[iRow]+",");
				writer.print(sales.unitprice[iRow]+",");
				writer.print(sales.insp[iRow]+"\n");
				
				//writer.print(sales.cluster[iRow]+"\n");
				
			}
			writer.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void main(String args[]){
		Sales sales=new Sales();
		SalesData salesData=new SalesData(sales);
		
		Kmeans kmeans= new Kmeans(salesData);
		kmeans.unsupervisedLearning(sales,salesData);
		kmeans.predictCluster(sales, salesData);
		kmeans.writeToFile(sales);
	}
}

